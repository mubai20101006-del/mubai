<?php
header('Content-Type: application/json');

$host = $_POST['host'] ?? '';
$dbname = $_POST['dbname'] ?? '';
$user = $_POST['user'] ?? '';
$pass = $_POST['pass'] ?? '';

if (empty($host) || empty($dbname) || empty($user)) {
    echo json_encode(['success' => false, 'message' => '缺少必要的数据库连接信息']);
    exit;
}

try {
    $conn = new mysqli($host, $user, $pass, $dbname);
    
    if ($conn->connect_error) {
        echo json_encode(['success' => false, 'message' => '数据库连接失败: ' . $conn->connect_error]);
        exit;
    }
    
    $sql = "SELECT card_key, is_used, created_at, used_at FROM card_keys ORDER BY created_at DESC";
    $result = $conn->query($sql);
    
    $cards = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $cards[] = $row;
        }
    }
    
    // 获取统计信息
    $stats_sql = "SELECT 
        COUNT(*) as total,
        SUM(is_used) as used,
        COUNT(*) - SUM(is_used) as available
        FROM card_keys";
    
    $stats_result = $conn->query($stats_sql);
    $stats = $stats_result->fetch_assoc();
    
    echo json_encode([
        'success' => true,
        'cards' => $cards,
        'stats' => $stats
    ]);
    
    $conn->close();
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => '获取卡密失败: ' . $e->getMessage()]);
}
?>