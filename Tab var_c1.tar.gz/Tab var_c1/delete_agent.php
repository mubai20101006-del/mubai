<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "dbname";

// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);

// 检查连接
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}

$sql = "SELECT * FROM agents";
$result = $conn->query($sql);

echo "<h1>代理管理界面</h1>";

if ($result->num_rows > 0) {
    echo "<table border='1'><tr><th>代理名</th><th>卡网链接</th><th>操作</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["name"]. "</td><td>" . $row["link"]. "</td><td><a href='delete_agent.php?id=" . $row["id"] . "'>删除</a></td></tr>";
    }
    echo "</table>";
} else {
    echo "没有代理记录";
}

$conn->close();
?>
