<?php
session_start();

// 数据库配置
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "dbname";

// 真实的下载链接
$real_download_url = " "; // 修改这个

header('Content-Type: application/json');

// 只处理POST请求
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$action = $_POST['action'] ?? '';
$cardKey = $_POST['card_key'] ?? '';

if (empty($cardKey) || empty($action)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing parameters']);
    exit;
}

// 创建数据库连接
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit;
}

if ($action === 'verify') {
    // 验证卡密是否存在且未使用
    $sql = "SELECT id, is_used FROM card_keys WHERE card_key = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $cardKey);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        $stmt->close();
        $conn->close();
        echo json_encode(['success' => false, 'message' => '卡密无效']);
        exit;
    }

    $row = $result->fetch_assoc();
    $stmt->close();

    // 如果您希望卡密只能使用一次，可以检查is_used字段

    // 生成一次性下载令牌
    $downloadToken = bin2hex(random_bytes(16));
    $expires = date('Y-m-d H:i:s', time() + 300); // 5分钟后过期

    $updateSql = "UPDATE card_keys SET one_time_token = ?, token_expires = ? WHERE card_key = ?";
    $updateStmt = $conn->prepare($updateSql);
    $updateStmt->bind_param("sss", $downloadToken, $expires, $cardKey);
    $updateStmt->execute();
    $updateStmt->close();

    $conn->close();

    echo json_encode([
        'success' => true,
        'download_url' => $real_download_url, // 这个URL是直接下载的URL，但注意我们实际上是通过download.php来验证令牌的
        'download_token' => $downloadToken // 实际上，前端不需要这个令牌，因为下载是通过表单提交到download.php的，但这里为了简单直接返回了URL
    ]);
} else {
    $conn->close();
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
?>