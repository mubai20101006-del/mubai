<?php
// 数据库配置
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "dbname";

// 创建数据库连接
$conn = new mysqli($servername, $username, $password, $dbname);

// 检查连接
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}

// 设置字符集
$conn->set_charset("utf8");

// 获取POST数据
$data = json_decode(file_get_contents('php://input'), true);

// 提取表单数据
$name = $data['name'];
$qq = $data['qq'];
$email = $data['email'];
$orderId = $data['orderId'];
$bugType = $data['bugType'];
$content = $data['content'];

// 准备SQL语句
$sql = "INSERT INTO bug_reports (name, qq, email, order_id, bug_type, content, submit_time) 
        VALUES (?, ?, ?, ?, ?, ?, NOW())";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssss", $name, $qq, $email, $orderId, $bugType, $content);

// 执行SQL语句
$response = [];
if ($stmt->execute()) {
    $response['success'] = true;
    $response['message'] = "反馈提交成功";
    
    // 发送邮件通知（可选）
    $to = "mubai_012@qq.com"; // 替换为您的邮箱
    $subject = "新的Bug反馈: " . $bugType;
    $message = "姓名: $name\nQQ: $qq\n邮箱: $email\n订单号: $orderId\n反馈类型: $bugType\n反馈内容: $content";
    $headers = "From: bug-report@yourwebsite.com";
    
    mail($to, $subject, $message, $headers);
} else {
    $response['success'] = false;
    $response['message'] = "错误: " . $sql . "<br>" . $conn->error;
}

// 关闭连接
$stmt->close();
$conn->close();

// 返回JSON响应
header('Content-Type: application/json');
echo json_encode($response);
?>