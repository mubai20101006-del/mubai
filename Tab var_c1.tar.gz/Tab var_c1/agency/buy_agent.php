<?php
// agency/buy_agent.php

// 开启所有错误报告
error_reporting(E_ALL);
ini_set('display_errors', 1); //生产环境下建议0

// 设置字符编码
header('Content-Type: text/html; charset=UTF-8');

// 引入配置文件
$config_path = dirname(__DIR__) . '/config.php';
if (!file_exists($config_path)) {
    die("错误: 配置文件不存在 - " . $config_path);
}

require_once $config_path;

// 检查数据库连接
if (!isset($pdo)) {
    die("错误: 数据库连接未初始化");
}

// 从URL路径中提取代理名称
$request_uri = $_SERVER['REQUEST_URI'];
$pattern = '/\/agency\/buy_([^\/\.]+)\.html$/';

if (!preg_match($pattern, $request_uri, $matches)) {
    // 如果URL格式不匹配，尝试从查询参数获取
    if (isset($_GET['agent'])) {
        $agent_name = $_GET['agent'];
    } else {
        // 没有代理参数，重定向到官网
        header("Location: https://realstry.xyz");
        exit;
    }
} else {
    $agent_name = $matches[1];
}

// 查询数据库获取代理的卡网链接
try {
    $stmt = $pdo->prepare("SELECT agent_name, card_net_url FROM agents WHERE agent_name = ?");
    $stmt->execute([$agent_name]);
    $agent = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$agent) {
        // 代理不存在，重定向到默认购买页面
        header("Location: https://lv.youxi186.com/shop/loveyou");
        exit;
    }
} catch (PDOException $e) {
    die("数据库查询错误: " . $e->getMessage());
}

// 读取模板文件
$template_path = dirname(__DIR__) . '/agency_template.html';
if (!file_exists($template_path)) {
    die("错误: 模板文件不存在 - " . $template_path);
}

$template_content = file_get_contents($template_path);
if ($template_content === false) {
    die("错误: 无法读取模板文件");
}

// 替换模板中的占位符
$template_content = str_replace(
    ['{%AGENT_NAME%}', '{%AGENT_URL%}'],
    [htmlspecialchars($agent['agent_name']), $agent['card_net_url']],
    $template_content
);

// 输出最终内容
echo $template_content;
exit;
?>