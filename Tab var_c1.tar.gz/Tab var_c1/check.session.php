<?php
session_start();
header('Content-Type: application/json');

$deviceFingerprint = $_POST['device_fingerprint'] ?? '';

// 检查SESSION中的验证状态
if (isset($_SESSION['verified_card']) && 
    isset($_SESSION['device_fingerprint']) && 
    $_SESSION['device_fingerprint'] === $deviceFingerprint &&
    time() - $_SESSION['verified_time'] < 300) { // 5分钟内有效
    
    echo json_encode([
        'success' => true,
        'verified' => true,
        'card_key' => $_SESSION['verified_card']
    ]);
} else {
    echo json_encode([
        'success' => true,
        'verified' => false
    ]);
}
?>