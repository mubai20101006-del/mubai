<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "dbname";

// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);

// 获取代理英文名
if (isset($_GET['agent'])) {
    $agent_name = $_GET['agent'];

    // 查找代理对应的购买页面 URL
    $stmt = $conn->prepare("SELECT buy_page_url FROM agents WHERE agent_name = ?");
    $stmt->bind_param("s", $agent_name);
    $stmt->execute();
    $stmt->bind_result($buy_page_url);
    $stmt->fetch();

    if ($buy_page_url) {
        // 设置自动跳转时间为 5 秒
        echo "<!DOCTYPE html>
              <html lang='zh'>
              <head>
                  <meta charset='UTF-8'>
                  <meta http-equiv='refresh' content='5;url=$buy_page_url'>
                  <title>跳转中...</title>
              </head>
              <body>
                  <h1>即将跳转到购买页面...</h1>
                  <p>如果没有自动跳转，请点击下面的链接：</p>
                  <a href='$buy_page_url' target='_blank'>$buy_page_url</a>
              </body>
              </html>";
    } else {
        echo "代理不存在";
    }

    $stmt->close();
}
$conn->close();
?>