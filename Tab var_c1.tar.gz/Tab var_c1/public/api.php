<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// 错误报告设置
error_reporting(E_ALL);
ini_set('display_errors', 0); // 生产环境设为0

// DeepSeek API配置
$api_key = 'sk-77777777777788888888888';
$api_url = 'https://api.deepseek.com/v1/chat/completions';

// 获取POST数据
$input = file_get_contents('php://input');

// 检查是否使用FormData
if (!empty($_POST['message'])) {
    $message = trim($_POST['message']);
    $conversation_history = isset($_POST['conversationHistory']) ? 
        json_decode($_POST['conversationHistory'], true) : [];
} else {
    // 如果不是FormData，尝试解析JSON
    $data = json_decode($input, true);
    $message = isset($data['message']) ? trim($data['message']) : '';
    $conversation_history = isset($data['conversationHistory']) ? $data['conversationHistory'] : [];
}

// 验证输入
if (empty($message)) {
    echo json_encode([
        'success' => false,
        'error' => '消息不能为空'
    ]);
    exit;
}

try {
    // 构建消息数组
    $messages = [];
    
    // 添加历史消息
    if (!empty($conversation_history) && is_array($conversation_history)) {
        foreach ($conversation_history as $msg) {
            if (isset($msg['role']) && isset($msg['content'])) {
                $messages[] = [
                    'role' => $msg['role'],
                    'content' => $msg['content']
                ];
            }
        }
    }
    
    // 添加当前用户消息
    $messages[] = [
        'role' => 'user',
        'content' => $message
    ];
    
    // 准备请求数据
    $request_data = [
        'model' => 'deepseek-chat',
        'messages' => $messages,
        'stream' => false,
        'max_tokens' => 2048
    ];
    
    // 初始化cURL
    $ch = curl_init();
    
    curl_setopt_array($ch, [
        CURLOPT_URL => $api_url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($request_data),
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $api_key
        ],
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => true
    ]);
    
    // 执行请求
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    
    curl_close($ch);
    
    // 检查cURL错误
    if ($curl_error) {
        throw new Exception('cURL错误: ' . $curl_error);
    }
    
    // 检查HTTP状态码
    if ($http_code !== 200) {
        throw new Exception('API请求失败，HTTP代码: ' . $http_code . ' 响应: ' . $response);
    }
    
    // 解析响应
    $response_data = json_decode($response, true);
    
    if (!isset($response_data['choices'][0]['message']['content'])) {
        throw new Exception('API响应格式错误: ' . $response);
    }
    
    // 获取AI回复
    $ai_reply = $response_data['choices'][0]['message']['content'];
    
    // 返回成功响应
    echo json_encode([
        'success' => true,
        'reply' => $ai_reply
    ]);
    
} catch (Exception $e) {
    // 记录错误日志
    error_log('DeepSeek API错误: ' . $e->getMessage());
    
    // 返回错误响应
    echo json_encode([
        'success' => false,
        'error' => '服务暂时不可用，请稍后重试'
    ]);
}
?>