<?php
$host = $_GET['host'] ?? '';
$dbname = $_GET['dbname'] ?? '';
$user = $_GET['user'] ?? '';
$pass = $_GET['pass'] ?? '';

if (empty($host) || empty($dbname) || empty($user)) {
    die('缺少必要的数据库连接信息');
}

try {
    $conn = new mysqli($host, $user, $pass, $dbname);
    
    if ($conn->connect_error) {
        die('数据库连接失败: ' . $conn->connect_error);
    }
    
    $sql = "SELECT card_key, is_used, created_at, used_at FROM card_keys ORDER BY created_at DESC";
    $result = $conn->query($sql);
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=tab_cards_export_' . date('Y-m-d') . '.csv');
    
    $output = fopen('php://output', 'w');
    fputcsv($output, ['卡密', '状态', '创建时间', '使用时间']);
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $status = $row['is_used'] ? '已使用' : '未使用';
            fputcsv($output, [
                $row['card_key'],
                $status,
                $row['created_at'],
                $row['used_at'] ?: '未使用'
            ]);
        }
    }
    
    $conn->close();
    exit;
} catch (Exception $e) {
    die('导出卡密失败: ' . $e->getMessage());
}
?>