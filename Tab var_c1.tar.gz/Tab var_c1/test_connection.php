<?php
header('Content-Type: application/json');

$host = $_POST['host'] ?? '';
$dbname = $_POST['dbname'] ?? '';
$user = $_POST['user'] ?? '';
$pass = $_POST['pass'] ?? '';

if (empty($host) || empty($dbname) || empty($user)) {
    echo json_encode(['success' => false, 'message' => '缺少必要的数据库连接信息']);
    exit;
}

try {
    $conn = new mysqli($host, $user, $pass, $dbname);
    
    if ($conn->connect_error) {
        echo json_encode(['success' => false, 'message' => '数据库连接失败: ' . $conn->connect_error]);
    } else {
        echo json_encode(['success' => true, 'message' => '数据库连接成功']);
    }
    
    $conn->close();
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => '数据库连接异常: ' . $e->getMessage()]);
}
?>