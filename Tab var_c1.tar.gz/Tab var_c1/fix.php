<?php
// test_db.php - 数据库连接测试
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "开始数据库连接测试...<br>";

$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "dbname";

try {
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    if ($conn->connect_error) {
        die("❌ 数据库连接失败: " . $conn->connect_error);
    } else {
        echo "✅ 数据库连接成功<br>";
    }
    
    // 测试创建表
    $sql = "CREATE TABLE IF NOT EXISTS downloadip (
        id INT AUTO_INCREMENT PRIMARY KEY,
        ip_address VARCHAR(45) UNIQUE,
        reason TEXT,
        status ENUM('blocked', 'whitelist') DEFAULT 'blocked',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )";
    
    if ($conn->query($sql) === TRUE) {
        echo "✅ 表创建成功或已存在<br>";
    } else {
        echo "❌ 表创建失败: " . $conn->error . "<br>";
    }
    
    $conn->close();
    
} catch (Exception $e) {
    die("❌ 异常错误: " . $e->getMessage());
}

echo "测试完成！";
?>