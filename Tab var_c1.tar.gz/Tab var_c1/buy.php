<?php
require_once 'config.php';

// 获取代理名称
$agentName = isset($_GET['agent']) ? $_GET['agent'] : '';

if (empty($agentName)) {
    header("HTTP/1.0 404 Not Found");
    die('代理名称不能为空');
}

try {
    // 从数据库获取代理信息
    $stmt = $pdo->prepare("SELECT * FROM agents WHERE agent_name = ?");
    $stmt->execute([$agentName]);
    $agent = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$agent) {
        header("HTTP/1.0 404 Not Found");
        die('找不到指定的代理');
    }
    
    // 显示代理购买页面
    // 这里可以输出HTML或使用模板
    echo "显示代理: " . htmlspecialchars($agent['agent_name']) . " 的购买页面";
    echo "卡网链接: " . htmlspecialchars($agent['card_net_url']);
    
} catch (PDOException $e) {
    header("HTTP/1.0 500 Internal Server Error");
    die('数据库查询失败');
}
?>