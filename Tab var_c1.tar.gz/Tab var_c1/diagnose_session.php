<?php
session_start();
header('Content-Type: application/json');

// 测试会话功能
$_SESSION['test_time'] = time();
$_SESSION['test_string'] = '会话测试成功';

if (isset($_SESSION['test_time']) && isset($_SESSION['test_string'])) {
    echo json_encode([
        'success' => true,
        'message' => '会话功能正常',
        'session_id' => session_id(),
        'session_status' => session_status()
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => '会话功能异常'
    ]);
}
?>