<?php
// download.php - 完整版（包含调试和IP拉黑功能）

// 开启错误显示（调试用，生产环境请关闭）
error_reporting(E_ALL);
ini_set('display_errors', 1);

// 记录错误到文件
function logError($message) {
    $error_log = "[" . date('Y-m-d H:i:s') . "] ERROR: " . $message . "\n";
    file_put_contents('error_log.txt', $error_log, FILE_APPEND | LOCK_EX);
}

// 记录信息到文件
function logInfo($message) {
    $info_log = "[" . date('Y-m-d H:i:s') . "] INFO: " . $message . "\n";
    file_put_contents('debug_log.txt', $info_log, FILE_APPEND | LOCK_EX);
}

// 简单的IP获取函数
function getClientIP() {
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($ips[0]);
    } elseif (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } else {
        return $_SERVER['REMOTE_ADDR'];
    }
}

// 检查IP黑名单函数
function checkIPBlacklist($ip_address) {
    logInfo("开始检查IP黑名单: " . $ip_address);
    
    // 1. 检查文件黑名单
    $blacklist_file = 'blacklist.txt';
    if (file_exists($blacklist_file)) {
        logInfo("检查文件黑名单: " . $blacklist_file);
        $blacklisted_ips = file($blacklist_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($blacklisted_ips as $black_ip) {
            $black_ip = trim($black_ip);
            if ($black_ip === $ip_address) {
                logInfo("IP在文件黑名单中找到: " . $ip_address);
                return true;
            }
        }
    } else {
        logInfo("文件黑名单不存在: " . $blacklist_file);
    }
    
    // 2. 检查数据库黑名单
    try {
        logInfo("开始检查数据库黑名单");
        $servername = "localhost";
        $username = "tabcc_top";
        $password = "zhangxu1006";
        $dbname = "tabcc_top";
        
        $conn = new mysqli($servername, $username, $password, $dbname);
        
        if ($conn->connect_error) {
            logError("数据库连接失败: " . $conn->connect_error);
            return false; // 数据库连接失败，不阻止下载
        }
        
        // 检查downloadip表是否存在
        $table_check = $conn->query("SHOW TABLES LIKE 'downloadip'");
        if ($table_check->num_rows == 0) {
            logInfo("downloadip表不存在，跳过数据库黑名单检查");
            $conn->close();
            return false;
        }
        
        // 查询IP是否在黑名单中
        $stmt = $conn->prepare("SELECT id FROM downloadip WHERE ip_address = ? AND is_active = 1");
        if (!$stmt) {
            logError("准备数据库语句失败: " . $conn->error);
            $conn->close();
            return false;
        }
        
        $stmt->bind_param("s", $ip_address);
        $stmt->execute();
        $stmt->store_result();
        
        $is_blacklisted = ($stmt->num_rows > 0);
        
        if ($is_blacklisted) {
            logInfo("IP在数据库黑名单中找到: " . $ip_address);
        }
        
        $stmt->close();
        $conn->close();
        
        return $is_blacklisted;
        
    } catch (Exception $e) {
        logError("数据库黑名单检查异常: " . $e->getMessage());
        return false; // 异常情况下不阻止下载
    }
}

try {
    // 检查是否POST请求
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('无效的请求方法');
    }

    // 获取下载类型
    if (!isset($_POST['download_type'])) {
        throw new Exception('缺少下载类型参数');
    }
    
    $download_type = trim($_POST['download_type']);
    logInfo("收到下载请求: " . $download_type);

    // 下载链接配置
    $download_links = array(
        'no_inject' => '123456',
        'local_mode' => '123456' // 合并为一个本地模式链接
    );

    // 验证下载类型
    if (!array_key_exists($download_type, $download_links)) {
        throw new Exception('无效的下载类型: ' . $download_type);
    }

    // 获取下载URL
    $download_url = $download_links[$download_type];
    logInfo("下载URL: " . $download_url);

    // 获取客户端信息
    $ip_address = getClientIP();
    $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'Unknown';
    $download_time = date('Y-m-d H:i:s');
    
    logInfo("客户端IP: " . $ip_address);

    // ========== IP黑名单检查 ==========
    if (checkIPBlacklist($ip_address)) {
        logInfo("IP被拒绝访问: " . $ip_address);
        header('HTTP/1.1 403 Forbidden');
        echo "<h1>访问被拒绝</h1>";
        echo "<p>您的IP地址 ($ip_address) 已被列入黑名单，无法下载资源。</p>";
        
        // 记录黑名单访问尝试
        $blacklist_log = "[$download_time] BLACKLISTED_ACCESS - IP: $ip_address | Type: $download_type\n";
        @file_put_contents('security_log.txt', $blacklist_log, FILE_APPEND | LOCK_EX);
        exit();
    }

    // 记录下载日志到文件
    $log_entry = "[$download_time] IP: $ip_address | Type: $download_type | URL: $download_url\n";
    if (file_put_contents('download_log.txt', $log_entry, FILE_APPEND | LOCK_EX) === false) {
        logError("无法写入下载日志文件");
    }

/*
    // 可选：记录到数据库
    try {
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "dbname";
        
        $conn = new mysqli($servername, $username, $password, $dbname);
        
        if (!$conn->connect_error) {
            // 创建下载日志表（如果不存在）
            $create_sql = "CREATE TABLE IF NOT EXISTS download_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                ip_address VARCHAR(45),
                download_type VARCHAR(50),
                user_agent TEXT,
                download_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )";
            $conn->query($create_sql);
            
            // 插入记录
            $stmt = $conn->prepare("INSERT INTO download_logs (ip_address, download_type, user_agent) VALUES (?, ?, ?)");
            if ($stmt) {
                $stmt->bind_param("sss", $ip_address, $download_type, $user_agent);
                $stmt->execute();
                $stmt->close();
                logInfo("下载记录已保存到数据库");
            }
            $conn->close();
        }
    } catch (Exception $e) {
        logError("数据库记录异常: " . $e->getMessage());
    }
*/

    // 执行重定向
    logInfo("开始重定向到: " . $download_url);
    header("Location: " . $download_url);
    exit();

} catch (Exception $e) {
    // 捕获异常并记录
    $error_message = $e->getMessage();
    logError("异常: " . $error_message);
    
    // 显示友好的错误信息
    header('Content-Type: text/html; charset=utf-8');
    echo "<h1>下载系统错误</h1>";
    echo "<p>错误信息: " . htmlspecialchars($error_message) . "</p>";
    echo "<p>请联系系统管理员。</p>";
    exit();
}
?>