<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');

/* ---------- 数据库配置 ---------- */
$host = 'localhost';
$user = 'username';
$pass = 'password';
$db   = 'username';
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => '数据库连接失败']);
    exit;
}
$conn->set_charset('utf8');

/* ---------- 自动建表（含 reason 字段） ---------- */
$conn->query("CREATE TABLE IF NOT EXISTS ip_blacklist (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    ip_address  VARCHAR(45) UNIQUE,
    banned_at   DATETIME,
    reason      VARCHAR(255)
)");
$conn->query("CREATE TABLE IF NOT EXISTS bug_reports (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100),
    qq          VARCHAR(20),
    email       VARCHAR(100),
    order_id    VARCHAR(100),
    bug_type    VARCHAR(100),
    content     TEXT,
    ip_address  VARCHAR(45),
    submit_time DATETIME
)");

/* ---------- 获取 IP ---------- */
function getClientIP(): string
{
    if (!empty($_SERVER['HTTP_CLIENT_IP']))            return $_SERVER['HTTP_CLIENT_IP'];
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))      return $_SERVER['HTTP_X_FORWARDED_FOR'];
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}
$userIP = getClientIP();

/* ---------- 黑名单检测 ---------- */
$stmt = $conn->prepare("SELECT 1 FROM ip_blacklist WHERE ip_address = ? LIMIT 1");
if (!$stmt) die(json_encode(['success' => false, 'message' => '黑名单检测失败']));
$stmt->bind_param('s', $userIP);
$stmt->execute();
if ($stmt->get_result()->num_rows) {
    echo json_encode(['success' => false, 'message' => '您的IP已被拉黑，无法提交反馈']);
    exit;
}
$stmt->close();

/* ---------- 1 小时内次数 ---------- */
$stmt = $conn->prepare("SELECT COUNT(*) AS cnt FROM bug_reports WHERE ip_address = ? AND submit_time > DATE_SUB(NOW(), INTERVAL 1 HOUR)");
if (!$stmt) die(json_encode(['success' => false, 'message' => '频次检测失败']));
$stmt->bind_param('s', $userIP);
$stmt->execute();
$cnt = $stmt->get_result()->fetch_assoc()['cnt'] ?? 0;
$stmt->close();

if ($cnt >= 2) {
    $reason = '1小时内提交≥2次';          // 自动原因
    $ban    = $conn->prepare("INSERT INTO ip_blacklist (ip_address, banned_at, reason) VALUES (?, NOW(), ?)");
    if (!$ban) die(json_encode(['success' => false, 'message' => '拉黑-prepare 失败']));
    $ban->bind_param('ss', $userIP, $reason);
    if (!$ban->execute()) die(json_encode(['success' => false, 'message' => '拉黑-execute 失败']));
    $ban->close();
    echo json_encode(['success' => false, 'message' => '提交过于频繁，您的IP已被拉黑']);
    exit;
}

/* ---------- 接收表单 ---------- */
$post = [];
foreach (['name','qq','email','orderId','bugType','content'] as $k) {
    $post[$k] = trim($_POST[$k] ?? '');
    if ($post[$k] === '') {
        echo json_encode(['success' => false, 'message' => "字段 $k 不能为空"]);
        exit;
    }
}

/* ---------- 写入反馈 ---------- */
$stmt = $conn->prepare(
    "INSERT INTO bug_reports (name, qq, email, order_id, bug_type, content, ip_address, submit_time)
     VALUES (?, ?, ?, ?, ?, ?, ?, NOW())"
);
if (!$stmt) die(json_encode(['success' => false, 'message' => '插入-prepare 失败']));
$stmt->bind_param('sssssss',
    $post['name'], $post['qq'], $post['email'],
    $post['orderId'], $post['bugType'], $post['content'], $userIP
);
$ok = $stmt->execute();
$stmt->close();
$conn->close();

/* ---------- 返回结果 ---------- */
echo json_encode([
    'success' => $ok,
    'message' => $ok ? '反馈提交成功' : '插入失败，请稍后再试'
]);
?>
