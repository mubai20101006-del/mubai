// 淡色渐变数组
const lightGradients = [
    'gradient-1',
    'gradient-2',
    'gradient-3',
    'gradient-4',
    'gradient-5',
    'gradient-6',
    'gradient-7',
    'gradient-8',
    'gradient-9',
    'gradient-10'
];

// 设置随机渐变背景
function setRandomGradient() {
    const randomIndex = Math.floor(Math.random() * lightGradients.length);
    const selectedGradient = lightGradients[randomIndex];
    
    // 移除所有渐变类
    document.body.classList.remove(...lightGradients);
    
    // 添加选中的渐变类
    document.body.classList.add(selectedGradient);
}

// QQ浏览器检测函数
function isQQBrowser() {
    const userAgent = navigator.userAgent;
    return userAgent.indexOf('QQBrowser') > -1 || 
           userAgent.indexOf('QQ/') > -1;
}

// 访问计数和缓存清除功能
function checkVisitCount() {
    const visitKey = 'tab_client_visit_count';
    let visitCount = parseInt(localStorage.getItem(visitKey)) || 0;
    
    visitCount++;
    localStorage.setItem(visitKey, visitCount.toString());
    
    // 访问5次后清除所有缓存
    if (visitCount >= 5) {
        localStorage.clear();
        console.log('已访问5次，清除所有缓存数据');
        // 重置计数
        localStorage.setItem(visitKey, '0');
    }
}

// 招募开发者弹窗功能
function initRecruitModal() {
    const recruitModal = document.getElementById('recruit-modal');
    const closeRecruitModal = document.getElementById('close-recruit-modal');
    const contactQQBtn = document.getElementById('contact-qq-btn');
    const dontShowRecruitAgainCheckbox = document.getElementById('dont-show-recruit-again');
    
    // 检查是否在一周内不再显示
    function shouldShowRecruitModal() {
        const dontShowUntil = localStorage.getItem('tab_recruit_dont_show_until');
        if (!dontShowUntil) return true;
        
        const now = Date.now();
        return now > parseInt(dontShowUntil);
    }
    
    // 显示弹窗
    function showRecruitModal() {
        if (shouldShowRecruitModal()) {
            setTimeout(() => {
                recruitModal.style.display = 'flex';
            }, 3000); // 延迟3秒显示
        }
    }
    
    // 关闭弹窗
    function closeModal() {
        recruitModal.style.display = 'none';
        
        // 如果勾选了"一周内不再显示"
        if (dontShowRecruitAgainCheckbox && dontShowRecruitAgainCheckbox.checked) {
            const now = Date.now();
            const oneWeek = 7 * 24 * 60 * 60 * 1000; // 一周的毫秒数
            const dontShowUntil = now + oneWeek;
            localStorage.setItem('tab_recruit_dont_show_until', dontShowUntil.toString());
        }
    }
    
    // 联系QQ
    function contactQQ() {
        // 这里可以跳转到QQ联系页面或复制QQ号
        const qqNumber = '3534797215';
        if (navigator.clipboard) {
            navigator.clipboard.writeText(qqNumber).then(() => {
                alert('QQ号已复制到剪贴板: ' + qqNumber);
            });
        } else {
            // 备用方案
            prompt('请手动复制QQ号:', qqNumber);
        }
        closeModal();
    }
    
    // 绑定事件
    if (closeRecruitModal) {
        closeRecruitModal.addEventListener('click', closeModal);
    }
    
    if (contactQQBtn) {
        contactQQBtn.addEventListener('click', contactQQ);
    }
    
    // 点击背景关闭
    if (recruitModal) {
        recruitModal.addEventListener('click', function(e) {
            if (e.target === recruitModal) {
                closeModal();
            }
        });
    }
    
    // 在内测弹窗关闭后显示招募弹窗
    const betaModal = document.getElementById('beta-modal');
    if (betaModal) {
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.type === 'attributes' && mutation.attributeName === 'style') {
                    if (betaModal.style.display === 'none') {
                        setTimeout(showRecruitModal, 1000); // 内测弹窗关闭1秒后显示招募弹窗
                    }
                }
            });
        });
        
        observer.observe(betaModal, {
            attributes: true,
            attributeFilter: ['style']
        });
    } else {
        // 如果没有内测弹窗，直接显示招募弹窗
        showRecruitModal();
    }
}

// 内测弹窗功能
function initBetaModal() {
    const betaModal = document.getElementById('beta-modal');
    const closeBetaModal = document.getElementById('close-beta-modal');
    const viewProgressBtn = document.getElementById('view-progress-btn');
    const dontShowAgainCheckbox = document.getElementById('dont-show-again');
    
    // 检查是否在一天内不再显示
    function shouldShowBetaModal() {
        const dontShowUntil = localStorage.getItem('tab_beta_dont_show_until');
        if (!dontShowUntil) return true;
        
        const now = Date.now();
        return now > parseInt(dontShowUntil);
    }
    
    // 显示弹窗
    function showBetaModal() {
        if (shouldShowBetaModal()) {
            setTimeout(() => {
                betaModal.style.display = 'flex';
            }, 1000); // 延迟1秒显示，让页面先加载
        }
    }
    
    // 关闭弹窗
    function closeModal() {
        betaModal.style.display = 'none';
        
        // 如果勾选了"一天内不再显示"
        if (dontShowAgainCheckbox && dontShowAgainCheckbox.checked) {
            const now = Date.now();
            const oneDay = 24 * 60 * 60 * 1000; // 一天的毫秒数
            const dontShowUntil = now + oneDay;
            localStorage.setItem('tab_beta_dont_show_until', dontShowUntil.toString());
        }
    }
    
    // 查看内测进度
    function viewProgress() {
        // 这里可以跳转到内测进度页面
        window.open('Pro/index.html', '_blank');
        closeModal();
    }
    
    // 绑定事件
    if (closeBetaModal) {
        closeBetaModal.addEventListener('click', closeModal);
    }
    
    if (viewProgressBtn) {
        viewProgressBtn.addEventListener('click', viewProgress);
    }
    
    // 点击背景关闭
    if (betaModal) {
        betaModal.addEventListener('click', function(e) {
            if (e.target === betaModal) {
                closeModal();
            }
        });
    }
    
    // 显示弹窗
    showBetaModal();
}

// 侧边导航菜单功能
function initNavigation() {
    const menuToggle = document.getElementById('menu-toggle');
    const sideNav = document.getElementById('side-nav');
    const overlay = document.getElementById('overlay');

    if (menuToggle && sideNav && overlay) {
        menuToggle.onclick = () => {
            sideNav.classList.add('open');
            overlay.style.display = 'block';
        };

        overlay.onclick = () => {
            sideNav.classList.remove('open');
            overlay.style.display = 'none';
        };
    }
}

// 访问频率限制
function initRateLimit() {
    const KEY = 'tab_ban';
    const LIMIT = 10;
    const DURATION = 60 * 1000;
    const banMask = document.getElementById('banMask');
    const cdSpan = document.getElementById('banCountdown');

    if (!banMask || !cdSpan) return;

    const now = () => Date.now();

    function getHits() {
        let arr = JSON.parse(localStorage.getItem(KEY) || '[]');
        return arr.filter(t => now() - t < DURATION);
    }

    function record() {
        const arr = getHits();
        arr.push(now());
        localStorage.setItem(KEY, JSON.stringify(arr));
        if (arr.length >= LIMIT) {
            localStorage.setItem(KEY + '_banStart', now());
            ban();
        }
    }

    function ban() {
        banMask.style.display = 'flex';
        const start = Number(localStorage.getItem(KEY + '_banStart'));
        const tick = () => {
            const left = Math.ceil((DURATION - (now() - start)) / 1000);
            if (left <= 0) {
                localStorage.removeItem(KEY);
                localStorage.removeItem(KEY + '_banStart');
                banMask.style.display = 'none';
                location.reload();
            } else {
                cdSpan.textContent = left;
                setTimeout(tick, 1000);
            }
        };
        tick();
    }

    const banStart = localStorage.getItem(KEY + '_banStart');
    if (banStart && now() - Number(banStart) < DURATION) {
        ban();
    } else {
        record();
    }
}

// 鼠标跟随效果
function initMouseEffect() {
    document.addEventListener('mousemove', function(e) {
        const cursor = document.createElement('div');
        cursor.style.position = 'fixed';
        cursor.style.left = e.clientX + 'px';
        cursor.style.top = e.clientY + 'px';
        cursor.style.width = '10px';
        cursor.style.height = '10px';
        cursor.style.background = 'rgba(255, 255, 255, 0.5)';
        cursor.style.borderRadius = '50%';
        cursor.style.pointerEvents = 'none';
        cursor.style.zIndex = '9999';
        cursor.style.animation = 'cursorFade 1s ease-out forwards';
        
        document.body.appendChild(cursor);
        
        setTimeout(() => {
            if (cursor.parentNode) {
                cursor.remove();
            }
        }, 1000);
    });
}

// 在页面加载时执行所有初始化
document.addEventListener('DOMContentLoaded', function() {
    // 设置随机渐变背景
    setRandomGradient();
    
    // 检查是否是QQ浏览器
    if (isQQBrowser()) {
        const qqWarning = document.getElementById('qqbrowser-warning');
        if (qqWarning) {
            qqWarning.style.display = 'flex';
            
            // 添加继续访问按钮事件
            const continueBtn = document.getElementById('qqbrowser-continue');
            if (continueBtn) {
                continueBtn.addEventListener('click', function() {
                    qqWarning.style.display = 'none';
                });
            }
        }
    }
    
    // 执行访问计数检查
    checkVisitCount();
    
    // 公告栏点击事件
    const announcementBar = document.getElementById('announcement-bar');
    if (announcementBar) {
        announcementBar.addEventListener('click', function() {
            window.location.href = 'aplisk.html';
        });
    }
    
    // 初始化各个功能模块
    initBetaModal();
    initRecruitModal(); // 新增这行
    initNavigation();
    initRateLimit();
    initMouseEffect();
});

// 添加一些保护措施（可选）
document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
});

document.addEventListener('keydown', function(e) {
    // 禁用 F12
    if (e.key === 'F12') {
        e.preventDefault();
        return false;
    }
    // 禁用 Ctrl+Shift+I
    if (e.ctrlKey && e.shiftKey && e.key === 'I') {
        e.preventDefault();
        return false;
    }
    // 禁用 Ctrl+U
    if (e.ctrlKey && e.key === 'u') {
        e.preventDefault();
        return false;
    }
});