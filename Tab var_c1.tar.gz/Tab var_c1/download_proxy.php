<?php
// download_proxy.php - 代理下载
session_start();

$file_map = [
    'no_inject' => '***.***.***.***',
    'android_14' => '***.***.***.***', 
    'android_old' => '***.***.***.***',
];

$file_id = $_GET['file_id'] ?? '';

if (isset($file_map[$file_id])) {
    // 记录下载日志
    $log = date('Y-m-d H:i:s') . " - IP: " . $_SERVER['REMOTE_ADDR'] . " - File: " . $file_id . "\n";
    file_put_contents('download_log.txt', $log, FILE_APPEND);
    
    // 直接重定向到真实下载链接
    header("Location: " . $file_map[$file_id]);
    exit;
} else {
    die('下载链接无效');
}
?>