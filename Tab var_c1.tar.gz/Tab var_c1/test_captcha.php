<?php
// test_captcha.php
session_start();

if (isset($_POST['test_captcha'])) {
    $input = $_POST['test_captcha'];
    $stored = isset($_SESSION['captcha']) ? $_SESSION['captcha'] : '未设置';
    
    $result = (strtoupper($input) === strtoupper($stored)) ? '成功' : '失败';
    
    // 清除验证码
    unset($_SESSION['captcha']);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>验证码测试</title>
</head>
<body>
    <h1>验证码测试结果</h1>
    
    <?php if (isset($result)): ?>
        <p>输入: <?php echo htmlspecialchars($input); ?></p>
        <p>存储: <?php echo htmlspecialchars($stored); ?></p>
        <p>结果: <strong><?php echo $result; ?></strong></p>
    <?php endif; ?>
    
    <p><a href="diagnose.php">返回诊断页面</a></p>
</body>
</html>