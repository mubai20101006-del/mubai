<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>卡密验证 - Tab Client</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #6C63FF;
            --primary-light: #837dff;
            --secondary: #36D1DC;
            --accent: #FF5E62;
            --light: #f8f9fa;
            --dark: #343a40;
            --success: #28a745;
            --warning: #ffc107;
            --danger: #dc3545;
            --glass-bg: rgba(255, 255, 255, 0.1);
            --glass-border: rgba(255, 255, 255, 0.15);
            --card-bg: rgba(17, 25, 40, 0.8);
            --text-primary: #ffffff;
            --text-secondary: rgba(255, 255, 255, 0.8);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', 'PingFang SC', -apple-system, BlinkMacSystemFont, sans-serif;
        }

        body {
            min-height: 100vh;
            background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
            color: var(--text-primary);
            overflow-x: hidden;
            line-height: 1.6;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            position: relative;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: 
                radial-gradient(circle at 20% 30%, rgba(108, 99, 255, 0.15) 0%, transparent 50%),
                radial-gradient(circle at 80% 70%, rgba(54, 209, 220, 0.15) 0%, transparent 50%);
            pointer-events: none;
            z-index: -1;
        }

        .container {
            width: 100%;
            max-width: 480px;
            z-index: 1;
        }

        .glass-card {
            background: var(--card-bg);
            backdrop-filter: blur(16px) saturate(180%);
            -webkit-backdrop-filter: blur(16px) saturate(180%);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.25);
            transition: transform 0.4s ease, box-shadow 0.4s ease;
            overflow: hidden;
        }

        .glass-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.3);
        }

        .header {
            text-align: center;
            padding: 40px 30px 30px;
            background: rgba(0, 0, 0, 0.2);
            border-bottom: 1px solid var(--glass-border);
            position: relative;
        }

        .header::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            border-radius: 2px;
        }

        .logo {
            font-size: 3rem;
            font-weight: 800;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 15px;
            letter-spacing: 1px;
            text-shadow: 0 2px 10px rgba(108, 99, 255, 0.3);
        }

        .title {
            font-size: 2rem;
            margin-bottom: 15px;
            font-weight: 600;
            background: linear-gradient(90deg, #fff, #e0e7ff);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .subtitle {
            opacity: 0.85;
            margin-bottom: 10px;
            font-size: 1.1rem;
            font-weight: 300;
            color: var(--text-secondary);
        }

        .form-container {
            padding: 30px 35px 40px;
        }

        .form-group {
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-bottom: 12px;
            font-weight: 500;
            font-size: 1.1rem;
            color: var(--text-primary);
        }

        .input-group {
            display: flex;
            align-items: center;
            background: rgba(255, 255, 255, 0.08);
            border-radius: 12px;
            padding: 0 20px;
            transition: all 0.3s ease;
            border: 1px solid transparent;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .input-group:focus-within {
            background: rgba(255, 255, 255, 0.12);
            box-shadow: 0 0 0 3px rgba(108, 99, 255, 0.25);
            border-color: var(--primary);
        }

        .input-group i {
            color: rgba(255, 255, 255, 0.7);
            font-size: 1.3rem;
            margin-right: 15px;
        }

        input {
            width: 100%;
            padding: 18px 0;
            background: transparent;
            border: none;
            color: white;
            font-size: 1.15rem;
            outline: none;
            letter-spacing: 0.5px;
        }

        input::placeholder {
            color: rgba(255, 255, 255, 0.5);
        }

        .btn {
            width: 100%;
            padding: 18px;
            border-radius: 12px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            font-size: 1.15rem;
            letter-spacing: 0.5px;
            position: relative;
            overflow: hidden;
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: 0.5s;
        }

        .btn:hover::before {
            left: 100%;
        }

        .btn-primary {
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            color: white;
            box-shadow: 0 6px 20px rgba(108, 99, 255, 0.4);
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(108, 99, 255, 0.5);
        }

        .btn-primary:active {
            transform: translateY(1px);
        }

        .message {
            text-align: center;
            margin-top: 20px;
            padding: 16px;
            border-radius: 12px;
            font-weight: 500;
            animation: fadeIn 0.4s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            backdrop-filter: blur(10px);
        }

        .error {
            background: rgba(220, 53, 69, 0.2);
            color: #ff6b6b;
            border: 1px solid rgba(220, 53, 69, 0.3);
        }

        .success {
            background: rgba(40, 167, 69, 0.2);
            color: #51cf66;
            border: 1px solid rgba(40, 167, 69, 0.3);
        }

        .hidden {
            display: none;
        }

        .download-info {
            margin-top: 30px;
            text-align: center;
            animation: fadeIn 0.6s ease;
        }

        .download-link {
            display: inline-flex;
            align-items: center;
            gap: 15px;
            padding: 20px 50px;
            font-size: 1.3rem;
            font-weight: 700;
            border-radius: 70px;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            color: white;
            text-decoration: none;
            box-shadow: 0 10px 30px rgba(108, 99, 255, 0.5);
            transition: all 0.4s ease;
            margin: 25px 0;
            position: relative;
            overflow: hidden;
        }

        .download-link::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: 0.5s;
        }

        .download-link:hover {
            transform: translateY(-4px) scale(1.03);
            box-shadow: 0 15px 35px rgba(108, 99, 255, 0.6);
        }

        .download-link:hover::before {
            left: 100%;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(15px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .spinner {
            animation: spin 1.1s linear infinite;
            margin-right: 10px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
           100% { transform: rotate(360deg); }
        }

        .device-info {
            margin-top: 20px;
            font-size: 1rem;
            opacity: 0.85;
            text-align: center;
            padding: 14px;
            background: rgba(255, 193, 7, 0.1);
            border-radius: 12px;
            color: #ffd43b;
            border: 1px solid rgba(255, 193, 7, 0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .progress-container {
            width: 100%;
            height: 12px;
            background: rgba(255, 255, 255, 0.15);
            border-radius: 10px;
            margin: 25px 0;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .progress-bar {
            height: 100%;
            width: 0%;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            border-radius: 10px;
            transition: width 0.7s cubic-bezier(0.22, 0.61, 0.36, 1);
            position: relative;
            overflow: hidden;
        }

        .progress-bar::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            bottom: 0;
            right: 0;
            background-image: linear-gradient(
                -45deg, 
                rgba(255, 255, 255, 0.2) 25%, 
                transparent 25%, 
                transparent 50%, 
                rgba(255, 255, 255, 0.2) 50%, 
                rgba(255, 255, 255, 0.2) 75%, 
                transparent 75%, 
                transparent
            );
            z-index: 1;
            background-size: 30px 30px;
            animation: move 1.5s linear infinite;
            overflow: hidden;
        }

        @keyframes move {
            0% { background-position: 0 0; }
            100% { background-position: 30px 30px; }
        }

        .download-status {
            font-size: 1.1rem;
            margin: 15px 0;
            min-height: 24px;
            font-weight: 500;
        }

        .success-animation {
            text-align: center;
            margin: 20px 0;
        }

        .checkmark {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            display: block;
            stroke-width: 5;
            stroke: #4CAF50;
            stroke-miterlimit: 10;
            box-shadow: 0 0 20px rgba(76, 175, 80, 0.3);
            animation: fill .4s ease-in-out .4s forwards, scale .3s ease-in-out .9s both;
            margin: 0 auto;
        }

        .checkmark-circle {
            stroke-dasharray: 166;
            stroke-dashoffset: 166;
            stroke-width: 5;
            stroke-miterlimit: 10;
            stroke: #4CAF50;
            fill: none;
            animation: stroke 0.6s cubic-bezier(0.65, 0, 0.45, 1) forwards;
        }

        .checkmark-check {
            transform-origin: 50% 50%;
            stroke-dasharray: 48;
            stroke-dashoffset: 48;
            animation: stroke 0.3s cubic-bezier(0.65, 0, 0.45, 1) 0.8s forwards;
        }

        @keyframes stroke {
            100% { stroke-dashoffset: 0; }
        }

        @keyframes scale {
            0%, 100% { transform: none; }
            50% { transform: scale3d(1.1, 1.1, 1); }
        }

        @keyframes fill {
            100% { box-shadow: inset 0px 0px 0px 30px rgba(76, 175, 80, 0.1); }
        }

        .debug-info {
            margin-top: 20px;
            padding: 15px;
            background: rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            font-size: 0.9rem;
            color: var(--text-secondary);
        }

        @media (max-width: 576px) {
            .container {
                padding: 10px;
            }
            
            .form-container {
                padding: 25px 20px 30px;
            }
            
            .header {
                padding: 30px 20px 25px;
            }
            
            .title {
                font-size: 1.7rem;
            }
            
            .logo {
                font-size: 2.5rem;
            }
            
            .download-link {
                padding: 16px 35px;
                font-size: 1.15rem;
            }
            
            .input-group {
                padding: 0 15px;
            }
            
            input {
                padding: 16px 0;
                font-size: 1.05rem;
            }
            
            .btn {
                padding: 16px;
                font-size: 1.05rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="glass-card">
            <div class="header">
                <div class="logo">Tab Client</div>
                <h1 class="title">卡密验证</h1>
                <p class="subtitle">请输入您的卡密以下载客户端</p>
            </div>
            
            <div class="form-container">
                <div class="form-group">
                    <label for="card-key"><i class="fas fa-key fa-sm"></i> 卡密</label>
                    <div class="input-group">
                        <i class="fas fa-key"></i>
                        <input type="text" id="card-key" placeholder="请输入您的卡密" autocomplete="off">
                    </div>
                </div>
                
                <button id="verify-btn" class="btn btn-primary">
                    <i class="fas fa-check-circle"></i>验证卡密
                </button>
                
                <div id="message" class="message hidden"></div>
                
                <div class="device-info">
                    <i class="fas fa-info-circle"></i> 每个卡密只能在一台设备上使用
                </div>
                
                <div id="download-section" class="download-info hidden">
                    <div class="success-animation">
                        <svg class="checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52">
                            <circle class="checkmark-circle" cx="26" cy="26" r="25" fill="none"/>
                            <path class="checkmark-check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
                        </svg>
                    </div>
                    
                    <h2>验证成功！</h2>
                    <p>您的下载请求正在处理中...</p>
                    
                    <div class="progress-container">
                        <div class="progress-bar" id="download-progress"></div>
                    </div>
                    
                    <p id="download-status" class="download-status">准备下载文件</p>
                    
                    <a href="#" id="direct-download" class="download-link">
                        <i class="fas fa-download"></i>立即下载客户端
                    </a>
                </div>

                <div class="debug-info">
                    <p><strong>调试信息：</strong></p>
                    <p>如果遇到验证失败，请检查：</p>
                    <ol>
                        <li>卡密是否正确（示例：wewewewe111）</li>
                        <li>数据库连接配置是否正确</li>
                        <li>卡密是否已在其他设备使用</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <script>
    // 验证函数
    function verifyCardKey(cardKey) {
        // 验证逻辑
        return new Promise((resolve) => {
            setTimeout(() => {
                // 验证逻辑
                const validKeys = ['a', 'b', 'c', '1', 'x'];   // 修改这个
                
                if (validKeys.includes(cardKey)) {
                    resolve({
                        success: true,
                        message: '卡密验证成功',
                        download_url: 'url'
                    });
                } else {
                    resolve({
                        success: false,
                        message: '卡密无效，请检查后重试'
                    });
                }
            }, 1500);
        });
    }

    document.addEventListener('DOMContentLoaded', function() {
        const cardKeyInput = document.getElementById('card-key');
        const verifyBtn = document.getElementById('verify-btn');
        const messageEl = document.getElementById('message');
        const downloadSection = document.getElementById('download-section');
        const downloadProgress = document.getElementById('download-progress');
        const downloadStatus = document.getElementById('download-status');
        const directDownload = document.getElementById('direct-download');
        
        // 验证卡密
        verifyBtn.addEventListener('click', function() {
            const cardKey = cardKeyInput.value.trim();
            
            if (!cardKey) {
                showMessage('请输入卡密', 'error');
                return;
            }
            
            // 显示加载状态
            verifyBtn.innerHTML = '<i class="fas fa-spinner spinner"></i>验证中...';
            verifyBtn.disabled = true;
            
            // 发送验证请求
            verifyCardKey(cardKey)
                .then(data => {
                    if (data.success) {
                        showMessage('卡密验证成功！', 'success');
                        downloadSection.classList.remove('hidden');
                        
                        // 设置直接下载链接
                        directDownload.href = data.download_url;
                        
                        startDownloadProcess();
                    } else {
                        showMessage(data.message || '卡密无效，请检查后重试', 'error');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showMessage('验证失败，请稍后重试', 'error');
                })
                .finally(() => {
                    // 恢复按钮状态
                    verifyBtn.innerHTML = '<i class="fas fa-check-circle"></i>验证卡密';
                    verifyBtn.disabled = false;
                });
        });
        
        // 按回车键触发验证
        cardKeyInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                verifyBtn.click();
            }
        });
        
        function startDownloadProcess() {
            let progress = 0;
            const interval = setInterval(() => {
                progress += 2;
                downloadProgress.style.width = progress + '%';
                
                if (progress < 30) {
                    downloadStatus.textContent = "验证下载权限...";
                } else if (progress < 60) {
                    downloadStatus.textContent = "准备下载文件...";
                } else if (progress < 90) {
                    downloadStatus.textContent = "生成下载链接...";
                } else {
                    downloadStatus.textContent = "下载准备就绪";
                }
                
                if (progress >= 100) {
                    clearInterval(interval);
                    // 自动开始下载
                    setTimeout(() => {
                        directDownload.click();
                    }, 800);
                }
            }, 50);
        }
        
        function showMessage(text, type) {
            messageEl.innerHTML = `<i class="fas fa-${type === 'error' ? 'exclamation-circle' : 'check-circle'}"></i> ${text}`;
            messageEl.className = 'message ' + type;
            messageEl.classList.remove('hidden');
            
            // 5秒后隐藏消息
            setTimeout(() => {
                messageEl.classList.add('hidden');
            }, 5000);
        }
    });
    </script>
</body>
</html>