<?php
// config.php
// 数据库配置
define('DB_HOST', 'localhost');
define('DB_NAME', 'username');
define('DB_USER', 'username'); // 替换为您的数据库用户名
define('DB_PASS', 'password'); // 替换为您的数据库密码

// 创建数据库连接
try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("数据库连接失败: " . $e->getMessage());
}
?>