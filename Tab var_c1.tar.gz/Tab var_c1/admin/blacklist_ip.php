<?php
// 包含数据库配置
include 'db_config.php';

// 设置响应头为JSON
header('Content-Type: application/json');

// 获取请求方法
$method = $_SERVER['REQUEST_METHOD'];

// 处理不同请求
switch ($method) {
    case 'GET':
        // 获取黑名单列表
        getBlacklist();
        break;
    case 'POST':
        // 添加IP到黑名单
        addToBlacklist();
        break;
    case 'DELETE':
        // 从黑名单移除IP
        removeFromBlacklist();
        break;
    default:
        // 不支持的请求方法
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => '不支持的请求方法']);
        break;
}

// 获取黑名单列表
function getBlacklist() {
    global $conn;
    
    $page = isset($_GET['page']) ? intval($_GET['page']) : 1;
    $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 10;
    $offset = ($page - 1) * $limit;
    
    // 获取黑名单数据
    $sql = "SELECT * FROM ip_blacklist ORDER BY created_at DESC LIMIT $limit OFFSET $offset";
    $result = $conn->query($sql);
    
    $blacklist = [];
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $blacklist[] = $row;
        }
    }
    
    // 获取总数
    $countSql = "SELECT COUNT(*) as total FROM ip_blacklist";
    $countResult = $conn->query($countSql);
    $total = $countResult->fetch_assoc()['total'];
    
    echo json_encode([
        'success' => true,
        'data' => $blacklist,
        'total' => $total,
        'page' => $page,
        'total_pages' => ceil($total / $limit)
    ]);
}

// 添加IP到黑名单
function addToBlacklist() {
    global $conn;
    
    // 获取POST数据
    $data = json_decode(file_get_contents('php://input'), true);
    $ip = $data['ip'];
    $reason = $data['reason'] ?? '';
    
    // 验证IP格式
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'IP地址格式不正确']);
        return;
    }
    
    // 检查是否已在黑名单中
    $checkSql = "SELECT COUNT(*) as count FROM ip_blacklist WHERE ip_address = ?";
    $checkStmt = $conn->prepare($checkSql);
    $checkStmt->bind_param("s", $ip);
    $checkStmt->execute();
    $result = $checkStmt->get_result();
    $row = $result->fetch_assoc();
    
    if ($row['count'] > 0) {
        echo json_encode(['success' => false, 'message' => '该IP已在黑名单中']);
        return;
    }
    
    // 插入到黑名单
    $sql = "INSERT INTO ip_blacklist (ip_address, reason, created_at) VALUES (?, ?, NOW())";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $ip, $reason);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'IP已成功加入黑名单']);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => '添加失败: ' . $conn->error]);
    }