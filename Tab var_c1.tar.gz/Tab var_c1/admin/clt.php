<?php
header('Content-Type: application/json; charset=utf-8');

// 数据库配置
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "dbname";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => '数据库连接失败']);
    exit;
}
$conn->set_charset('utf8');

// 取 IP
$input = json_decode(file_get_contents('php://input'), true);
$ip = trim($input['ip'] ?? '');

if (!filter_var($ip, FILTER_VALIDATE_IP)) {
    echo json_encode(['success' => false, 'message' => 'IP 格式不正确']);
    exit;
}

// 事务清理
$conn->autocommit(false);

try {
    $stmt1 = $conn->prepare("DELETE FROM bug_reports WHERE ip_address = ?");
    $stmt2 = $conn->prepare("DELETE FROM ip_blacklist WHERE ip_address = ?");
    if (!$stmt1 || !$stmt2) throw new Exception('prepare 失败');

    $stmt1->bind_param('s', $ip);
    $stmt2->bind_param('s', $ip);
    $stmt1->execute();
    $stmt2->execute();

    $conn->commit();
    echo json_encode(['success' => true, 'message' => "已清理 $ip 的全部记录"]);
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} finally {
    $stmt1->close();
    $stmt2->close();
    $conn->close();
}
?>
