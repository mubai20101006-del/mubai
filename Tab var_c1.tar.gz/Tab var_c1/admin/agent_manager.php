<?php
// 数据库连接配置
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "dbname";

// 创建数据库连接
$conn = new mysqli($servername, $username, $password, $dbname);

// 检查连接
if ($conn->connect_error) {
    die("数据库连接失败: " . $conn->connect_error);
}

// 处理表单提交
$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $agentName = $_POST['agentName'];
    $buyUrl = $_POST['buyUrl'];
    
    // 验证输入
    if (!empty($agentName) && !empty($buyUrl)) {
        // 准备并绑定
        $stmt = $conn->prepare("INSERT INTO agents (name, buy_url) VALUES (?, ?)");
        $stmt->bind_param("ss", $agentName, $buyUrl);
        
        // 执行插入
        if ($stmt->execute()) {
            $message = "代理添加成功！";
        } else {
            $message = "错误: " . $stmt->error;
        }
        $stmt->close();
    } else {
        $message = "请填写所有字段！";
    }
}

// 获取所有代理
$agents = [];
$result = $conn->query("SELECT id, name, buy_url, created_at FROM agents ORDER BY created_at DESC");
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $agents[] = $row;
    }
}

// 处理代理跳转
$redirectUrl = "";
if (isset($_GET['agent'])) {
    $agentName = $_GET['agent'];
    $stmt = $conn->prepare("SELECT buy_url FROM agents WHERE name = ?");
    $stmt->bind_param("s", $agentName);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        header("Location: " . $row['buy_url']);
        exit();
    } else {
        $redirectUrl = "未找到代理: " . htmlspecialchars($agentName);
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>代理管理系统</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            color: #333;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        
        .container {
            width: 100%;
            max-width: 1200px;
            display: flex;
            flex-direction: column;
            gap: 30px;
        }
        
        header {
            text-align: center;
            color: white;
            padding: 20px;
        }
        
        header h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        }
        
        header p {
            font-size: 1.2rem;
            max-width: 800px;
            margin: 0 auto;
            line-height: 1.6;
        }
        
        .card-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
        }
        
        .card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
            overflow: hidden;
            width: 100%;
            max-width: 550px;
            min-height: 400px;
            transition: transform 0.3s ease;
        }
        
        .card:hover {
            transform: translateY(-5px);
        }
        
        .card-header {
            background: #4e54c8;
            color: white;
            padding: 20px;
            text-align: center;
            font-size: 1.5rem;
            font-weight: 600;
        }
        
        .card-body {
            padding: 25px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #4e54c8;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        
        .form-control:focus {
            border-color: #4e54c8;
            outline: none;
        }
        
        .btn {
            background: #4e54c8;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: background 0.3s;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        
        .btn:hover {
            background: #3a3eb3;
        }
        
        .btn i {
            margin-right: 8px;
        }
        
        .result-box {
            margin-top: 20px;
            padding: 15px;
            border-radius: 8px;
            background: #f8f9fa;
            border-left: 4px solid #4e54c8;
        }
        
        .result-box h4 {
            color: #4e54c8;
            margin-bottom: 10px;
        }
        
        .url-display {
            background: #e9ecef;
            padding: 10px;
            border-radius: 6px;
            word-break: break-all;
            font-family: monospace;
            margin: 10px 0;
        }
        
        .agents-list {
            list-style: none;
            margin-top: 20px;
            max-height: 250px;
            overflow-y: auto;
        }
        
        .agents-list li {
            padding: 10px 15px;
            background: #f8f9fa;
            margin-bottom: 10px;
            border-radius: 6px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .agent-name {
            font-weight: 500;
        }
        
        .agent-url {
            font-size: 0.9rem;
            color: #6c757d;
        }
        
        .instructions {
            background: #fff8e1;
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
            border-left: 4px solid #ffc107;
        }
        
        .instructions h4 {
            color: #ff9800;
            margin-bottom: 10px;
        }
        
        .instructions ol {
            padding-left: 20px;
        }
        
        .instructions li {
            margin-bottom: 8px;
        }
        
        .message {
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            text-align: center;
        }
        
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        @media (max-width: 768px) {
            .card-container {
                flex-direction: column;
                align-items: center;
            }
            
            .card {
                max-width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1><i class="fas fa-users-cog"></i> 代理管理系统</h1>
            <p>添加代理并生成专属购买链接，方便用户跳转到指定代理购买页面</p>
        </header>
        
        <div class="card-container">
            <div class="card">
                <div class="card-header">
                    <i class="fas fa-plus-circle"></i> 添加新代理
                </div>
                <div class="card-body">
                    <?php if (!empty($message)): ?>
                        <div class="message <?php echo strpos($message, '成功') !== false ? 'success' : 'error'; ?>">
                            <?php echo $message; ?>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="">
                        <div class="form-group">
                            <label for="agentName"><i class="fas fa-user-tie"></i> 代理英文名</label>
                            <input type="text" id="agentName" name="agentName" class="form-control" placeholder="例如：mubai" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="buyUrl"><i class="fas fa-link"></i> 购买页面URL</label>
                            <input type="url" id="buyUrl" name="buyUrl" class="form-control" placeholder="例如：https://example.com/buy.html" required>
                        </div>
                        
                        <button type="submit" class="btn">
                            <i class="fas fa-save"></i> 添加代理
                        </button>
                    </form>
                    
                    <div class="result-box">
                        <h4>生成的代理链接</h4>
                        <div id="generatedUrl" class="url-display">
                            <?php 
                            if (isset($_POST['agentName']) && !empty($_POST['agentName'])) {
                                echo "tabcc.top/agent_manager.php?agent=" . htmlspecialchars($_POST['agentName']);
                            } else {
                                echo "尚未生成链接";
                            }
                            ?>
                        </div>
                        <p>用户可通过此链接访问该代理的专属购买页面</p>
                    </div>
                    
                    <div class="instructions">
                        <h4><i class="fas fa-info-circle"></i> 使用说明</h4>
                        <ol>
                            <li>输入代理英文名和购买页面URL</li>
                            <li>点击"添加代理"按钮</li>
                            <li>系统将生成专属代理链接</li>
                            <li>将生成的链接分发给您的代理</li>
                            <li>用户访问链接后将跳转到购买页面</li>
                        </ol>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <i class="fas fa-list"></i> 已添加的代理
                </div>
                <div class="card-body">
                    <h3>代理列表</h3>
                    <p>以下是你已添加的代理及其专属链接：</p>
                    
                    <ul id="agentsList" class="agents-list">
                        <?php if (count($agents) > 0): ?>
                            <?php foreach ($agents as $agent): ?>
                                <li>
                                    <div>
                                        <span class="agent-name"><?php echo htmlspecialchars($agent['name']); ?></span>
                                        <div class="agent-url">tabcc.top/agent_manager.php?agent=<?php echo htmlspecialchars($agent['name']); ?></div>
                                    </div>
                                    <button class="btn copy-btn" style="padding: 5px 10px; font-size: 14px;" data-url="tabcc.top/agent_manager.php?agent=<?php echo htmlspecialchars($agent['name']); ?>">
                                        <i class="fas fa-copy"></i>
                                    </button>
                                </li>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <li>暂无代理数据</li>
                        <?php endif; ?>
                    </ul>
                    
                    <div class="instructions">
                        <h4><i class="fas fa-lightbulb"></i> 提示</h4>
                        <p>这些数据保存在MySQL数据库中，并通过PHP进行管理。</p>
                        <p>当用户访问代理链接时，系统会查询数据库并重定向到对应的购买页面。</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // 添加复制功能
            document.querySelectorAll('.copy-btn').forEach(button => {
                button.addEventListener('click', function() {
                    const urlToCopy = this.getAttribute('data-url');
                    navigator.clipboard.writeText(urlToCopy)
                        .then(() => {
                            alert('链接已复制到剪贴板: ' + urlToCopy);
                        });
                });
            });
            
            // 实时生成URL预览
            const agentNameInput = document.getElementById('agentName');
            const generatedUrl = document.getElementById('generatedUrl');
            
            agentNameInput.addEventListener('input', function() {
                if (this.value.trim() !== '') {
                    generatedUrl.textContent = 'tabcc.top/agent_manager.php?agent=' + this.value;
                } else {
                    generatedUrl.textContent = '尚未生成链接';
                }
            });
        });
    </script>
</body>
</html>