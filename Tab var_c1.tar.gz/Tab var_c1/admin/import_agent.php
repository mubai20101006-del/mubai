<?php
// import_agent.php
session_start();

// 检查管理员是否已登录
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('HTTP/1.1 401 Unauthorized');
    echo json_encode(['success' => false, 'message' => '未授权访问']);
    exit;
}

require_once 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => '无效的请求方法']);
    exit;
}

// 获取并验证输入
$agentName = filter_input(INPUT_POST, 'agentName', FILTER_SANITIZE_STRING);
$cardNetUrl = filter_input(INPUT_POST, 'cardNetUrl', FILTER_SANITIZE_URL);

if (empty($agentName) || empty($cardNetUrl)) {
    echo json_encode(['success' => false, 'message' => '代理名称和卡网链接不能为空']);
    exit;
}

// 验证代理名称格式（只允许字母、数字、下划线和连字符）
if (!preg_match('/^[a-zA-Z0-9_-]+$/', $agentName)) {
    echo json_encode(['success' => false, 'message' => '代理名称只能包含字母、数字、下划线和连字符']);
    exit;
}

// 验证URL格式
if (!filter_var($cardNetUrl, FILTER_VALIDATE_URL)) {
    // 尝试添加http://前缀后再次验证
    if (!preg_match("~^(?:f|ht)tps?://~i", $cardNetUrl)) {
        $cardNetUrl = "https://" . $cardNetUrl;
        
        if (!filter_var($cardNetUrl, FILTER_VALIDATE_URL)) {
            echo json_encode(['success' => false, 'message' => '无效的URL格式']);
            exit;
        }
    } else {
        echo json_encode(['success' => false, 'message' => '无效的URL格式']);
        exit;
    }
}

try {
    // 检查代理名称是否已存在
    $checkStmt = $pdo->prepare("SELECT id FROM agents WHERE agent_name = ?");
    $checkStmt->execute([$agentName]);
    
    if ($checkStmt->fetch()) {
        echo json_encode(['success' => false, 'message' => '代理名称已存在']);
        exit;
    }
    
    // 插入新代理
    $insertStmt = $pdo->prepare("INSERT INTO agents (agent_name, card_net_url) VALUES (?, ?)");
    $result = $insertStmt->execute([$agentName, $cardNetUrl]);
    
    if ($result) {
        echo json_encode([
            'success' => true, 
            'message' => '代理导入成功',
            'agent_link' => "http://" . $_SERVER['HTTP_HOST'] . "/agency/buy_" . $agentName . ".html"
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => '插入数据库失败']);
    }
} catch (PDOException $e) {
    // 记录详细错误信息到日志
    error_log("数据库错误: " . $e->getMessage());
    
    // 返回简化的错误信息给客户端
    if (strpos($e->getMessage(), 'Duplicate entry') !== false) {
        echo json_encode(['success' => false, 'message' => '代理名称已存在']);
    } else {
        echo json_encode(['success' => false, 'message' => '数据库操作失败，请检查日志获取详细信息']);
    }
}
?>