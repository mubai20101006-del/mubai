<?php
header('Content-Type: application/json');

$host = $_POST['host'] ?? '';
$dbname = $_POST['dbname'] ?? '';
$user = $_POST['user'] ?? '';
$pass = $_POST['pass'] ?? '';
$cards = $_POST['cards'] ?? '';

if (empty($host) || empty($dbname) || empty($user) || empty($cards)) {
    echo json_encode(['success' => false, 'message' => '缺少必要的参数']);
    exit;
}

try {
    $conn = new mysqli($host, $user, $pass, $dbname);
    
    if ($conn->connect_error) {
        echo json_encode(['success' => false, 'message' => '数据库连接失败: ' . $conn->connect_error]);
        exit;
    }
    
    $cards = json_decode($cards, true);
    $added = 0;
    $duplicates = 0;
    
    foreach ($cards as $card) {
        if (empty($card)) continue;
        
        // 检查卡密是否已存在
        $check_sql = "SELECT id FROM card_keys WHERE card_key = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("s", $card);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if ($check_result->num_rows > 0) {
            $duplicates++;
            $check_stmt->close();
            continue;
        }
        
        $check_stmt->close();
        
        // 插入新卡密
        $sql = "INSERT INTO card_keys (card_key, created_at) VALUES (?, NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $card);
        
        if ($stmt->execute()) {
            $added++;
        }
        
        $stmt->close();
    }
    
    echo json_encode([
        'success' => true,
        'added' => $added,
        'duplicates' => $duplicates,
        'message' => "成功添加 $added 个卡密，$duplicates 个重复卡密已跳过"
    ]);
    
    $conn->close();
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => '添加卡密失败: ' . $e->getMessage()]);
}
?>