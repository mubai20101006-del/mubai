<?php
// 启用错误报告
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 设置响应头
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// 处理预检请求
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

// 数据库配置
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "dbname";

// 创建数据库连接
$conn = new mysqli($servername, $username, $password, $dbname);

// 检查连接
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => '数据库连接失败: ' . $conn->connect_error]);
    exit;
}

// 设置字符集
$conn->set_charset("utf8");

// 确保表存在
$createTableSQL = "
CREATE TABLE IF NOT EXISTS ip_blacklist (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ip_address VARCHAR(45) NOT NULL,
    reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_ip (ip_address)
)";
if (!$conn->query($createTableSQL)) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => '创建表失败: ' . $conn->error]);
    exit;
}

// 获取请求数据
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $action = isset($_GET['action']) ? $_GET['action'] : 'get';
} else {
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    $action = isset($data['action']) ? $data['action'] : 'add';
}

// 处理不同操作
switch ($action) {
    case 'get':
        getBlacklist();
        break;
    case 'add':
        $ip = isset($data['ip']) ? $data['ip'] : '';
        $reason = isset($data['reason']) ? $data['reason'] : '';
        addToBlacklist($ip, $reason);
        break;
    case 'remove':
        $ip = isset($data['ip']) ? $data['ip'] : '';
        removeFromBlacklist($ip);
        break;
    case 'clear':
        clearBlacklist();
        break;
    default:
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => '未知操作']);
        break;
}

// 获取黑名单列表
function getBlacklist() {
    global $conn;
    
    $page = isset($_GET['page']) ? intval($_GET['page']) : 1;
    $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 10;
    $offset = ($page - 1) * $limit;
    
    // 获取黑名单数据
    $sql = "SELECT * FROM ip_blacklist ORDER BY created_at DESC LIMIT ? OFFSET ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $limit, $offset);
    
    if (!$stmt->execute()) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => '查询失败: ' . $stmt->error]);
        exit;
    }
    
    $result = $stmt->get_result();
    $blacklist = [];
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $blacklist[] = $row;
        }
    }
    
    $stmt->close();
    
    // 获取总数
    $countSql = "SELECT COUNT(*) as total FROM ip_blacklist";
    $countResult = $conn->query($countSql);
    
    if (!$countResult) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => '计数查询失败: ' . $conn->error]);
        exit;
    }
    
    $total = $countResult->fetch_assoc()['total'];
    
    echo json_encode([
        'success' => true,
        'data' => $blacklist,
        'total' => $total,
        'page' => $page,
        'total_pages' => ceil($total / $limit)
    ]);
}

// 添加IP到黑名单
function addToBlacklist($ip, $reason) {
    global $conn;
    
    // 验证IP格式
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'IP地址格式不正确']);
        return;
    }
    
    // 检查是否已在黑名单中
    $checkSql = "SELECT COUNT(*) as count FROM ip_blacklist WHERE ip_address = ?";
    $checkStmt = $conn->prepare($checkSql);
    $checkStmt->bind_param("s", $ip);
    $checkStmt->execute();
    $result = $checkStmt->get_result();
    $row = $result->fetch_assoc();
    $checkStmt->close();
    
    if ($row['count'] > 0) {
        echo json_encode(['success' => false, 'message' => '该IP已在黑名单中']);
        return;
    }
    
    // 插入到黑名单
    $sql = "INSERT INTO ip_blacklist (ip_address, reason) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $ip, $reason);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'IP已成功加入黑名单']);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => '添加失败: ' . $stmt->error]);
    }
    
    $stmt->close();
}

// 从黑名单移除IP
function removeFromBlacklist($ip) {
    global $conn;
    
    if (empty($ip)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'IP地址不能为空']);
        return;
    }
    
    // 从黑名单中删除
    $sql = "DELETE FROM ip_blacklist WHERE ip_address = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $ip);
    
    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo json_encode(['success' => true, 'message' => 'IP已从黑名单中移除']);
        } else {
            echo json_encode(['success' => false, 'message' => '该IP不在黑名单中']);
        }
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => '删除失败: ' . $stmt->error]);
    }
    
    $stmt->close();
}

// 清空黑名单
function clearBlacklist() {
    global $conn;
    
    $sql = "TRUNCATE TABLE ip_blacklist";
    
    if ($conn->query($sql)) {
        echo json_encode(['success' => true, 'message' => '黑名单已清空']);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => '清空失败: ' . $conn->error]);
    }
}

// 关闭数据库连接
$conn->close();
?>