<?php
// 数据库配置
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "dbname";

// 创建数据库连接
$conn = new mysqli($servername, $username, $password, $dbname);

// 检查连接
if ($conn->connect_error) {
    die("数据库连接失败: " . $conn->connect_error);
}

// 设置字符集
$conn->set_charset("utf8mb4");

// 处理文件上传
$message = "";
$success_count = 0;
$error_count = 0;
$duplicate_count = 0;
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['txt_file'])) {
    $file = $_FILES['txt_file'];
    
    // 检查文件上传是否成功
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $message = "文件上传失败，错误代码: " . $file['error'];
    } 
    // 检查文件类型
    elseif ($file['type'] !== 'text/plain' && pathinfo($file['name'], PATHINFO_EXTENSION) !== 'txt') {
        $message = "只支持 TXT 文件";
    }
    // 检查文件大小 (限制为 2MB)
    elseif ($file['size'] > 2097152) {
        $message = "文件大小不能超过 2MB";
    }
    else {
        // 读取文件内容
        $content = file_get_contents($file['tmp_name']);
        
        // 按行分割内容
        $lines = explode("\n", $content);
        
        // 准备插入语句
        $stmt = $conn->prepare("INSERT IGNORE INTO card_keys (card_key) VALUES (?)");
        
        if ($stmt === false) {
            $message = "准备语句失败: " . $conn->error;
        } else {
            // 开始事务处理，提高插入效率
            $conn->begin_transaction();
            
            foreach ($lines as $line) {
                $line = trim($line);
                
                // 跳过空行
                if (empty($line)) {
                    continue;
                }
                
                // 绑定参数并执行
                $stmt->bind_param("s", $line);
                
                if ($stmt->execute()) {
                    if ($stmt->affected_rows > 0) {
                        $success_count++;
                    } else {
                        $duplicate_count++;
                    }
                } else {
                    $error_count++;
                    $errors[] = "卡密 '{$line}' 插入失败: " . $stmt->error;
                }
            }
            
            // 提交事务
            $conn->commit();
            $stmt->close();
            
            $message = "导入完成! 成功: {$success_count}, 重复: {$duplicate_count}, 失败: {$error_count}";
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>批量导入卡密 - TXT文件</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #6C63FF;
            --secondary: #36D1DC;
            --accent: #FF5E62;
            --light: #f8f9fa;
            --dark: #343a40;
            --success: #28a745;
            --glass-bg: rgba(255, 255, 255, 0.15);
            --glass-border: rgba(255, 255, 255, 0.2);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', 'PingFang SC', -apple-system, sans-serif;
        }

        body {
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: var(--light);
            overflow-x: hidden;
            line-height: 1.6;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            background: var(--glass-bg);
            backdrop-filter: blur(12px) saturate(180%);
            border: 1px solid var(--glass-border);
            border-radius: 16px;
            padding: 30px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
        }

        .logo {
            font-size: 2.5rem;
            font-weight: 800;
            background: linear-gradient(90deg, var(--light), #e0e0e0);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 10px;
        }

        .title {
            font-size: 2rem;
            margin-bottom: 10px;
            font-weight: 600;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }

        input[type="file"] {
            width: 100%;
            padding: 12px;
            border-radius: 10px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            background: rgba(255, 255, 255, 0.1);
            color: white;
        }

        .btn {
            padding: 12px 25px;
            border-radius: 10px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            font-size: 1rem;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            color: white;
            box-shadow: 0 4px 15px rgba(108, 99, 255, 0.3);
        }

        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(108, 99, 255, 0.4);
        }

        .message {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            text-align: center;
        }

        .success {
            background: rgba(40, 167, 69, 0.2);
            color: #51cf66;
        }

        .error {
            background: rgba(220, 53, 69, 0.2);
            color: #ff6b6b;
        }

        .info-box {
            background: rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            padding: 20px;
            margin-top: 20px;
        }

        .stats {
            display: flex;
            justify-content: space-around;
            margin-top: 20px;
            text-align: center;
        }

        .stat {
            padding: 15px;
        }

        .stat-value {
            font-size: 2rem;
            font-weight: bold;
        }

        .stat-success {
            color: #51cf66;
        }

        .stat-warning {
            color: #ffd43b;
        }

        .stat-error {
            color: #ff6b6b;
        }

        .error-list {
            margin-top: 20px;
            max-height: 200px;
            overflow-y: auto;
            background: rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            padding: 15px;
        }

        .error-item {
            padding: 5px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        @media (max-width: 768px) {
            .stats {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="logo">Tab Client</div>
            <h1 class="title">批量导入卡密</h1>
            <p>从TXT文件导入卡密，每行一个</p>
        </div>

        <?php if (!empty($message)): ?>
            <div class="message <?php echo $error_count > 0 ? 'error' : 'success'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="txt_file">选择TXT文件</label>
                <input type="file" name="txt_file" id="txt_file" accept=".txt" required>
            </div>
            
            <button type="submit" class="btn">
                <i class="fas fa-upload"></i> 导入卡密
            </button>
        </form>

        <?php if ($success_count > 0 || $error_count > 0 || $duplicate_count > 0): ?>
            <div class="stats">
                <div class="stat">
                    <div class="stat-value stat-success"><?php echo $success_count; ?></div>
                    <div>成功导入</div>
                </div>
                <div class="stat">
                    <div class="stat-value stat-warning"><?php echo $duplicate_count; ?></div>
                    <div>重复卡密</div>
                </div>
                <div class="stat">
                    <div class="stat-value stat-error"><?php echo $error_count; ?></div>
                    <div>失败</div>
                </div>
            </div>
        <?php endif; ?>

        <?php if (!empty($errors)): ?>
            <div class="error-list">
                <h3>错误详情:</h3>
                <?php foreach ($errors as $error): ?>
                    <div class="error-item"><?php echo $error; ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <div class="info-box">
            <h3><i class="fas fa-info-circle"></i> 使用说明</h3>
            <ul>
                <li>选择包含卡密列表的TXT文件</li>
                <li>每行一个卡密，空行会自动跳过</li>
                <li>重复的卡密会被自动忽略</li>
                <li>文件大小限制: 2MB</li>
                <li>支持的文件格式: .txt</li>
                <li>导入前请确保数据库表结构正确</li>
            </ul>
            
            <h4>示例TXT文件格式:</h4>
            <pre style="background: rgba(0,0,0,0.2); padding: 10px; border-radius: 5px; overflow: auto;">
TAB20240901-ABCDEFGH
TAB20240902-IJKLMNOP
TAB20240903-QRSTUVWX
TAB20240904-YZ123456
TAB20240905-7890ABCD
            </pre>
        </div>
    </div>
</body>
</html>