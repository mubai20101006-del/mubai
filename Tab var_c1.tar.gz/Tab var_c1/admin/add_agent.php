<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "dbname";

// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);

// 检查连接
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $link = $_POST["link"];

    $sql = "INSERT INTO agents (name, link) VALUES ('$name', '$link')";

    if ($conn->query($sql) === TRUE) {
        echo "代理添加成功";
    } else {
        echo "错误: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>