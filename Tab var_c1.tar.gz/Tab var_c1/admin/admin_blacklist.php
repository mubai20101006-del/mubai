<?php
// blacklist_admin.php - 使用MySQL数据库的管理界面

// 数据库配置
$db_config = [
    'servername' => "localhost",
    'username' => "username",
    'password' => "password", 
    'dbname' => "dbname"
];

// 简单的身份验证
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    if ($_POST['password'] !== 'admin123') { // 请修改这个密码
        if ($_POST['password']) {
            $error = "密码错误";
        }
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title>管理员登录</title>
            <meta charset="utf-8">
            <style>
                body { font-family: Arial, sans-serif; max-width: 400px; margin: 100px auto; padding: 20px; }
                .login-form { background: #f5f5f5; padding: 30px; border-radius: 8px; }
                input[type="password"] { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ddd; border-radius: 4px; }
                button { background: #007cba; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; }
                .error { color: red; margin: 10px 0; }
            </style>
        </head>
        <body>
            <div class="login-form">
                <h2>IP黑名单管理</h2>
                <?php if (isset($error)) echo "<div class='error'>$error</div>"; ?>
                <form method="post">
                    <input type="password" name="password" placeholder="请输入管理员密码" required>
                    <button type="submit">登录</button>
                </form>
            </div>
        </body>
        </html>
        <?php
        exit();
    } else {
        $_SESSION['admin_logged_in'] = true;
    }
}

// 数据库连接
try {
    $conn = new mysqli(
        $db_config['servername'],
        $db_config['username'],
        $db_config['password'],
        $db_config['dbname']
    );
    
    if ($conn->connect_error) {
        throw new Exception("数据库连接失败: " . $conn->connect_error);
    }
} catch (Exception $e) {
    die("数据库连接错误: " . $e->getMessage());
}

$message = '';

// 处理添加IP
if ($_POST['action'] === 'add_ip') {
    $ip = trim($_POST['ip']);
    $note = trim($_POST['note'] ?? '');
    
    if (!empty($ip) && filter_var($ip, FILTER_VALIDATE_IP)) {
        // 检查是否已存在
        $check_stmt = $conn->prepare("SELECT id FROM downloadip WHERE ip_address = ?");
        $check_stmt->bind_param("s", $ip);
        $check_stmt->execute();
        $check_stmt->store_result();
        
        if ($check_stmt->num_rows === 0) {
            // 插入新记录
            $insert_stmt = $conn->prepare("INSERT INTO downloadip (ip_address, note) VALUES (?, ?)");
            $insert_stmt->bind_param("ss", $ip, $note);
            
            if ($insert_stmt->execute()) {
                $message = "成功添加IP: $ip 到黑名单";
            } else {
                $message = "添加失败: " . $insert_stmt->error;
            }
            
            $insert_stmt->close();
        } else {
            $message = "IP: $ip 已在黑名单中";
        }
        
        $check_stmt->close();
    } else {
        $message = "无效的IP地址";
    }
}

// 处理删除IP
if ($_POST['action'] === 'delete_ip') {
    $ip_to_delete = $_POST['ip_to_delete'];
    
    $delete_stmt = $conn->prepare("DELETE FROM downloadip WHERE ip_address = ?");
    $delete_stmt->bind_param("s", $ip_to_delete);
    
    if ($delete_stmt->execute()) {
        $message = "成功从黑名单移除IP: $ip_to_delete";
    } else {
        $message = "删除失败: " . $delete_stmt->error;
    }
    
    $delete_stmt->close();
}

// 处理启用/禁用
if ($_POST['action'] === 'toggle_ip') {
    $ip_to_toggle = $_POST['ip_to_toggle'];
    $new_status = $_POST['new_status'] === 'enable' ? 1 : 0;
    
    $toggle_stmt = $conn->prepare("UPDATE downloadip SET is_active = ? WHERE ip_address = ?");
    $toggle_stmt->bind_param("is", $new_status, $ip_to_toggle);
    
    if ($toggle_stmt->execute()) {
        $status_text = $new_status ? '启用' : '禁用';
        $message = "成功{$status_text}IP: $ip_to_toggle";
    } else {
        $message = "操作失败: " . $toggle_stmt->error;
    }
    
    $toggle_stmt->close();
}

// 获取当前黑名单
$blacklisted_ips = [];
$result = $conn->query("SELECT ip_address, created_at, note, is_active FROM downloadip ORDER BY created_at DESC");
if ($result) {
    $blacklisted_ips = $result->fetch_all(MYSQLI_ASSOC);
    $result->free();
}

// 获取下载日志中的IP（用于快速选择）
$download_ips = [];
$log_result = $conn->query("SELECT DISTINCT ip_address FROM download_logs ORDER BY download_time DESC LIMIT 20");
if ($log_result) {
    while ($row = $log_result->fetch_assoc()) {
        $download_ips[] = $row['ip_address'];
    }
    $log_result->free();
}

$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>IP黑名单管理 - MySQL版本</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body { font-family: Arial, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; background: #f5f5f5; }
        .container { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h1 { color: #333; border-bottom: 2px solid #007cba; padding-bottom: 10px; }
        .message { background: #d4edda; color: #155724; padding: 10px; border-radius: 4px; margin: 15px 0; }
        .section { margin: 30px 0; padding: 20px; background: #f8f9fa; border-radius: 6px; }
        input[type="text"], textarea { padding: 8px; width: 200px; border: 1px solid #ddd; border-radius: 4px; margin: 5px; }
        button { background: #007cba; color: white; padding: 8px 16px; border: none; border-radius: 4px; cursor: pointer; margin: 5px; }
        button.delete { background: #dc3545; }
        button.disable { background: #ffc107; color: black; }
        button.enable { background: #28a745; }
        table { width: 100%; border-collapse: collapse; margin: 15px 0; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #007cba; color: white; }
        tr:hover { background: #f5f5f5; }
        .status-active { color: #28a745; font-weight: bold; }
        .status-inactive { color: #dc3545; font-weight: bold; }
        .ip-list { max-height: 200px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; background: white; }
        .ip-item { padding: 5px; cursor: pointer; }
        .ip-item:hover { background: #e9ecef; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔒 IP黑名单管理系统 (MySQL)</h1>
        
        <?php if ($message): ?>
            <div class="message"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <div class="section">
            <h2>添加IP到黑名单</h2>
            <form method="post">
                <input type="hidden" name="action" value="add_ip">
                <input type="text" name="ip" placeholder="输入IP地址，如: 192.168.1.1" required>
                <input type="text" name="note" placeholder="备注(可选)">
                <button type="submit">一键拉黑</button>
            </form>
            
            <div style="margin-top: 15px;">
                <h3>最近访问的IP（点击快速选择）:</h3>
                <div class="ip-list">
                    <?php if (empty($download_ips)): ?>
                        <div>暂无下载记录</div>
                    <?php else: ?>
                        <?php foreach ($download_ips as $ip): ?>
                            <div class="ip-item" onclick="document.querySelector('input[name=ip]').value='<?php echo $ip; ?>'">
                                <?php echo htmlspecialchars($ip); ?>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="section">
            <h2>当前黑名单列表</h2>
            <?php if (empty($blacklisted_ips)): ?>
                <p>黑名单为空</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>IP地址</th>
                            <th>添加时间</th>
                            <th>备注</th>
                            <th>状态</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($blacklisted_ips as $ip_data): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($ip_data['ip_address']); ?></td>
                                <td><?php echo htmlspecialchars($ip_data['created_at']); ?></td>
                                <td><?php echo htmlspecialchars($ip_data['note'] ?? ''); ?></td>
                                <td>
                                    <?php if ($ip_data['is_active']): ?>
                                        <span class="status-active">已启用</span>
                                    <?php else: ?>
                                        <span class="status-inactive">已禁用</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <form method="post" style="display: inline;">
                                        <input type="hidden" name="action" value="delete_ip">
                                        <input type="hidden" name="ip_to_delete" value="<?php echo htmlspecialchars($ip_data['ip_address']); ?>">
                                        <button type="submit" class="delete" onclick="return confirm('确定要从黑名单移除 <?php echo $ip_data['ip_address']; ?> 吗？')">删除</button>
                                    </form>
                                    
                                    <?php if ($ip_data['is_active']): ?>
                                        <form method="post" style="display: inline;">
                                            <input type="hidden" name="action" value="toggle_ip">
                                            <input type="hidden" name="ip_to_toggle" value="<?php echo htmlspecialchars($ip_data['ip_address']); ?>">
                                            <input type="hidden" name="new_status" value="disable">
                                            <button type="submit" class="disable">禁用</button>
                                        </form>
                                    <?php else: ?>
                                        <form method="post" style="display: inline;">
                                            <input type="hidden" name="action" value="toggle_ip">
                                            <input type="hidden" name="ip_to_toggle" value="<?php echo htmlspecialchars($ip_data['ip_address']); ?>">
                                            <input type="hidden" name="new_status" value="enable">
                                            <button type="submit" class="enable">启用</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <div class="section">
            <h2>系统信息</h2>
            <p>数据库: <?php echo htmlspecialchars($db_config['dbname']); ?></p>
            <p>黑名单表: downloadip</p>
            <p>日志表: download_logs</p>
            <p>当前黑名单数量: <?php echo count($blacklisted_ips); ?></p>
        </div>
    </div>
</body>
</html>