<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// 数据库配置
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "dbname";

// 创建数据库连接
$conn = new mysqli($servername, $username, $password, $dbname);

// 检查连接
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => '数据库连接失败: ' . $conn->connect_error]);
    exit;
}

// 设置字符集
$conn->set_charset("utf8mb4");

// 获取POST数据
$data = json_decode(file_get_contents('php://input'), true);
$id = $data['id'];

// 删除反馈
$sql = "DELETE FROM bug_reports WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $id);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => '反馈删除成功']);
} else {
    echo json_encode(['success' => false, 'message' => '反馈删除失败: ' . $stmt->error]);
}

// 关闭连接
$stmt->close();
$conn->close();
?>