<?php
session_start();

// 创建验证码图像
$width = 120;
$height = 40;
$image = imagecreatetruecolor($width, $height);

// 设置背景和文本颜色
$bgColor = imagecolorallocate($image, 255, 255, 255);
$textColor = imagecolorallocate($image, 0, 0, 0);
$noiseColor = imagecolorallocate($image, 100, 100, 100);

// 填充背景
imagefilledrectangle($image, 0, 0, $width, $height, $bgColor);

// 生成随机验证码
$chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
$captcha = '';
for ($i = 0; $i < 5; $i++) {
    $captcha .= $chars[rand(0, strlen($chars) - 1)];
}

// 存储验证码到SESSION
$_SESSION['captcha'] = $captcha;

// 添加干扰线
for ($i = 0; $i < 5; $i++) {
    imageline($image, 
        rand(0, $width), rand(0, $height),
        rand(0, $width), rand(0, $height),
        $noiseColor);
}

// 添加干扰点
for ($i = 0; $i < 100; $i++) {
    imagesetpixel($image, rand(0, $width), rand(0, $height), $noiseColor);
}

// 写入验证码文本
$font = 5; // 使用内置字体
imagestring($image, $font, 20, 12, $captcha, $textColor);

// 输出图像
header('Content-Type: image/png');
imagepng($image);
imagedestroy($image);
?>